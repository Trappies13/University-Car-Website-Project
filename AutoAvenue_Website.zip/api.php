<?php
class CarApi {
//    private $api_key = "f7f406a387e8d7b4c4be";
    private $db_host = "wheatley.cs.up.ac.za";
    private $db_name = "u22502883";
    private $db_user = "u22502883";
    private $db_password = "W3KHQWNRIUOQ67INPJ6NGIJIZGFV7UXG";

    public function get_all_cars() {
        $request_body = file_get_contents('php://input');
        $search = json_decode($request_body, true);
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            header('Content-Type: application/json');
            echo json_encode(array('error' => 'Method not allowed'));
            return;
        }
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            http_response_code(400);
            header('Content-Type: application/json');
            echo json_encode(array('error' => 'Invalid JSON'));
            return;
        }
        
        $conn = new mysqli($this->db_host, $this->db_user, $this->db_password, $this->db_name);
        if ($conn->connect_error) {
            $response = array(
                'success' => false,
                'message' => 'Database connection failed: ' . $conn->connect_error
            );
            header('Content-Type: application/json');
            echo json_encode($response);
            return;
        }
        
        $api_key = $search['apikey'];
        
        $stmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE API_key = ?");
        $stmt->bind_param("s", $api_key);
        $stmt->execute();
        $stmt->bind_result($count);
        $stmt->fetch();
        $stmt->close();

        if ($count !== 1) {
            $response = array(
                'success' => false,
                'message' => 'Invalid API key'
            );
            header('Content-Type: application/json');
            echo json_encode($response);
            return;
        }
        
        $cache_key = md5($request_body);
        $cache_file = '/tmp/' . $cache_key;
        $cache_time = 3600;
        
        if (file_exists($cache_file) && time() - filemtime($cache_file) < $cache_time) {
            $response = json_decode(file_get_contents($cache_file), true);
        } else {
        if (isset($search['return']) && $search['return'] !== '*') {
            if (is_array($search['return'])) {
                $return_fields = implode(',', $search['return']);
            } else {
                $return_fields = $search['return'];
            }
            $return_fields = explode(',', $return_fields);
            $return_fields = array_map('trim', $return_fields);
            $return_fields = array_filter($return_fields, function($value) {
                return $value !== 'image';
            });
            $return_fields[] = 'id_trim';
            if (!empty($return_fields)) {
                $sql = "SELECT " . implode(',', $return_fields) . " FROM cars";
            } else {
                $sql = "SELECT * FROM cars";
            }
        } else {
            $sql = "SELECT * FROM cars";
        }   
        }
        
        $where_conditions = array();
        foreach ($search['search'] as $key => $value) {
            if (is_string($value) && !in_array($key, ['type', 'apikey', 'return', 'fuzzy'])) {
                $where_conditions[] = " LOWER(" . $key . ") LIKE '%" . strtolower($value) . "%'";
            }
        }
        if (!empty($where_conditions)) {
            $sql .= " WHERE " . implode(' AND ', $where_conditions);
        }
        
        if (isset($search['make'])) {
            $make = $search['make'];
            $sql .= " AND LOWER(make) LIKE '%" . strtolower($make) . "%'";
        }
        
        if (isset($search['model'])) {
            $model = $search['model'];
            $sql .= " AND LOWER(model) LIKE '%" . strtolower($model) . "%'";
        }
        
        if (isset($search['fuzzy']) && $search['fuzzy'] === 'false') {
            $sql = str_replace('LIKE', '=', $sql);
        }
        
        if (isset($search['sort']) && isset($search['order'])) {
            $sql .= " ORDER BY " . $search['sort'] . " " . $search['order'];
        }
        
        if (isset($search['limit'])) {
            $sql .= " LIMIT " . $search['limit'];
        }

        $result = $conn->query($sql);
        if ($result === false) {
            $response = array(
                'success' => "error",
                'message' => 'Query failed: ' . $conn->error
            );
            echo json_encode($response);
            return;
        }
        
        $cars = array();
        while ($row = $result->fetch_assoc()) {
            $car = array();
            foreach ($row as $key => $value) {
                if (in_array($key, $return_fields)) {
                    $car[$key] = $value;
                }
            }

            $image_url = 'https://wheatley.cs.up.ac.za/api/getimage?brand=' . urlencode(strtolower($row['make'])) . '&model=' . urlencode(strtolower($row['model']));
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $image_url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            $car['image'] = $response;
            
            $cars[] = $car;
        }
        $response = array(
            'success' => "success",
            'timestamp' => time(),
            'data' => $cars
        );
        
        header('Content-Type: application/json');
        echo json_encode($response);
        }
    
        public function get_rating($id) {
            $conn = new mysqli($this->db_host, $this->db_user, $this->db_password, $this->db_name);
            if ($conn->connect_error) {
                $response = array(
                    'success' => false,
                    'message' => 'Database connection failed: ' . $conn->connect_error
                );
                header('Content-Type: application/json');
                echo json_encode($response);
                return;
            }

            $sql = "SELECT rating as rating FROM ratings WHERE id_trim = " . $id;
            $result = $conn->query($sql);
            if ($result === false) {
                $response = array(
                    'success' => "error",
                    'message' => 'Query failed: ' . $conn->error
                );
                echo json_encode($response);
                return;
            }

            $row = $result->fetch_assoc();
            $response = array(
                'success' => true,
                'data' => array(
                'rating' => $row['rating']
                )
            );
            header('Content-Type: application/json');
            echo json_encode($response);
        }
    }

$car_api = new CarApi();
$car_api->get_all_cars();
?>