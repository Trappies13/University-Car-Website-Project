<?php
include('header.php');
include('auth.php');
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Brands</title>
        <link rel="stylesheet" href="css/brandStyles.css">
    </head>
    
    <body>
        <div id="loading"></div>
    <table class="product-container">
    </table>
        <script src="js/brands.js"></script>
    </body>    
</html>